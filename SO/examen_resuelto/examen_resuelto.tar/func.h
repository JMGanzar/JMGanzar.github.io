#define NUM_VOTOS 5 // Numero de votos que emite cada hijo
#define MIN_HIJOS 10
#define MAX_HIJOS 100

#define NUM_PAISES 26 // Numero de paises

typedef struct { 
    int pid ; // Pid del hijo 
    int paisesID[NUM_VOTOS]; // Listado de paises a los que vota cada hijo
    int votos[NUM_VOTOS]; // Voto emitido a cada pais correspondiente
    int pipehijo[2]; // Descriptores el pipe del hijo
} HIJO ;

bool CheckIfFileExists(const char* filename);
bool isNumber(char number[]);
void Sintaxis();
int RandInt(int M, int N);
int ContarLineasFichero(const char *filename);
void LeerFicheroPaises(char* filename, int numHijos, int listaPaisesVotar[MAX_HIJOS][NUM_VOTOS]);
void CrearPipes(int numHijos);
void ComunicarPaises(int numHijo, unsigned int *idPaises);
void RecibirPaises(int numHijo, unsigned int *idPaises);