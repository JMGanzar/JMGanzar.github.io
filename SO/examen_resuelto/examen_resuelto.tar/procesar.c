#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>   
#include <string.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>   
#include <stdbool.h>
#include <sys/wait.h>
#include "func.h"
#include "sem.h"

#define SSEED 99           //Semilla para el Semaforo
#define SHMSEED 35         //Semilla para la asignacion del segmento de memoria compartida
#define SHMPERMISOS 0644   //Permisos para el segmento de memoria compartida

HIJO *arrayHijos; // definimos un array de hijos para los Pipes

//Programa principal
int main( int argc, char *argv[] )
{
	//Declaramos las variables necesarias para la memoria compartida.
	int shmIdResults, shmResultsSize;
	int *shmResults;  

 	//Declaramos el semaforo mutex de acceso a la memoria compartida
	int sMutex;
 
	int pidP, pidC; //Para almacenar los PIDs del padre e hijos
	int i,j;        //iteradores genericos para bucles
	int numHijos;   //Para el numero de hijos
	
	// Vector 2D para almacenar los elementos del fichero de listas de paises a votar.
	// Lo dimensionamos para el número maximo de hijos.
	int listaPaisesVotar[MAX_HIJOS][NUM_VOTOS]; 

	int status;           //Para status de retorno de la llamada al sistema wait
	char buffer[200]="";  //Buffer genérico para llamadas al sistema write/read
 	FILE * fd;  //Descriptor de fichero para usarlo para fichero de resultados
	char paisesFile [100]= "";    //Para el nombre del fichero de listas de paises a votar generado en bash
	char resultadosFile[100]= ""; //Para el nombre del fichero de resultados

	//Control de paraḿetros y asignación a variables
	//Si error mostramos mensaje, sintaxis y terminamos con -1

	//BEGIN TODO 1 ***********************************************
		//Controlamos el numero de parametros.
		if(argc != 3){
			printf("ERROR: error en el numero de parametros [%d], se esperaban %d.\n",argc-1,2);
			Sintaxis();
			exit(-1);
		}
	//END TODO ***********************************************

	//BEGIN TODO 2 ***********************************************
		//Capturamos los datos  en las variables correspondientes
		// paisesFile     <-- argv[1]
		// resultadosFile <-- argv[2]
		strcpy(paisesFile, argv[1]);
		strcpy(resultadosFile, argv[2]);
	//END TODO ***********************************************
	
	//BEGIN TODO 3 ***********************************************
		//Comprobamos si el fichero de votacion existe. Si no exist, mostramos error y salimos 
		if (CheckIfFileExists(paisesFile) == 0){
			printf("ERROR: el fichero [%s] no existe.\n",paisesFile);
			Sintaxis();
			exit(-1);
		}
	//END TODO ***********************************************

	//BEGIN TODO 4 ***********************************************
		//Contamos el número de líneas del fichero paisesFile para ver cuantos hijos hay que crear.
		numHijos = ContarLineasFichero(paisesFile);
	//END TODO ***********************************************
	printf("En esta edición participan %d votantes\n",numHijos);

	//BEGIN TODO 5 ***********************************************
		// Creamos el array de estructuras para los numHijos hijos de forma dinámica utilizando malloc.
		// Obtendremos un puntero a estructura HIJO, (HIJO*) que asignaremosa arrayHijos, es decir, haremos un casting.
		arrayHijos = (HIJO*)malloc(numHijos*sizeof(HIJO));
	//END TODO ***********************************************

	//BEGIN TODO 6 ***********************************************
		//Definimos el tamaño, creamos el segmento de memoria compartida shmResults y asignamos correctamente los punteros.
		//Si Error mostramos mensaje y salimos
		shmResultsSize=NUM_PAISES*sizeof(int);
		//debug printf("Tamaño del segmento a pedir: %d\n",shmResultsSize); fflush(stdout);
		shmIdResults = shmget(ftok("./", SHMSEED), shmResultsSize, IPC_CREAT | SHMPERMISOS);
		if (shmIdResults==-1){
			printf("ERROR: error al crear el segmento de memoria compartida\n");
			exit(1);
		}
		//Apuntamos shmResults a la memoria compartida reservada 
		shmResults = shmat(shmIdResults,0,0);
	//END TODO ***********************************************

	//BEGIN TODO 7 ***********************************************
		// Inicializamos el vector shmResults con ceros
		memset(shmResults,0,shmResultsSize);
	//END TODO ***********************************************

	//debug printf("El padre ha inicializado el shmResults de memoria compartida %d con [%d][%d][%d]\n", shmIdResults, shmResults[0], shmResults[1], shmResults[2]); fflush(stdout);

	//BEGIN TODO 8 ***********************************************
		//Creamos el semáforo mutex de acceso al vector de resultados inicializado a sus valor correcto
		sMutex=sCreate(SSEED,1);  //Inicializar para que el primer proceso que llegue entre
	//END TODO ***********************************************

	//BEGIN TODO 9 ***********************************************
		//Llamamos a la funcion CrearPipes para que se cree un Pipe por cada hijo
		CrearPipes(numHijos);

		// Leemos y guardamos el contenido del archivo de votaciones en un vector 2D
		LeerFicheroPaises(paisesFile, numHijos, listaPaisesVotar);
	//END TODO ***********************************************

	//Guardamos el PID del padre en pidP.
	pidP=getpid();

	//BEGIN TODO 10***********************************************
		//---************ Bucle para crear a los hijos ************---
		//El padre crea en bucle a los numHijos. 
		//Cada hijo recibe por Pipe el listado de paises a los que va a votar. Después, genera la votación 
		// y actualiza el valor del vector de puntuaciones shmResults mediante exclusión mutua.
		//debug printf("El padre entra en el bucle de cración de los %d hijos\n",numHijos); fflush(stdout);
		//printf("El padre entra en el bucle de cración de los %d hijos\n",numHijos); fflush(stdout);
		for(i=0; i < numHijos; i++) { //El padre itera creando los hijos
			//Nota: La variable i es el índice del hijo

			//llamamos a la función fork obteniendo en la variable pidC el valor retornado
			pidC=fork();

			//Si no se ha podido crear al hijo mostramos error y salimos con -1
			if(pidC==-1){
				sprintf(buffer,"ERROR. Fork ha fallado al crear el hijo %d\n",i);
				perror(buffer);
				exit(-1);
			}

			//Determinamos si el pid es del padre o de un hijo
			if (pidC != 0) { //Código del padre
	      		//mantenimiento de la estructura de hijos (almacenamos el PID del hijo)
	      		arrayHijos[i].pid = pidC;
	   		} else { // Código hijo 
				//debug printf("  Hijo [%d] el padre me ha creado con pid %d\n",i,getpid()); fflush(stdout);
				//printf("  Hijo [%d] el padre me ha creado con pid %d\n",i,getpid()); fflush(stdout);
				
				//Inicializamos el generador de numeros aleatorios
				srand (getpid());

				// Leemos del pipe la lista de paises a votar y lo almacenamos en el vector correspondiente de la estructura de cada hijo
				RecibirPaises(i, arrayHijos[i].paisesID);
				//debug printf("  Hijo [%d] He recibido los paises correctamente [%d-%d-%d-%d-%d]\n",i,arrayHijos[i].paisesID[0],arrayHijos[i].paisesID[1],arrayHijos[i].paisesID[2],arrayHijos[i].paisesID[3],arrayHijos[i].paisesID[4]); fflush(stdout);
				//printf("  Hijo [%d] He recibido los paises correctamente [%d-%d-%d-%d-%d]\n",i,arrayHijos[i].paisesID[0],arrayHijos[i].paisesID[1],arrayHijos[i].paisesID[2],arrayHijos[i].paisesID[3],arrayHijos[i].paisesID[4]); fflush(stdout);

				// Generamos el voto para cada pais y lo almacenamos en el vector correspondiente de la estructura de cada hijo
				// Las puntuaciones posibles podrán ser de 1 a 12, ambos incluidos
				for (j=0; j<NUM_VOTOS; j++){
					arrayHijos[i].votos[j] = RandInt(1, 12);
				}

				// Utilizamos el semaforo para acceder a la zona de memoria compartida y sumamos las puntuaciones correspondientes a cada pais
				sWait(sMutex);
					//debug printf("  Hijo [%d] Estoy escribiendo en memoria compartida\n",i); fflush(stdout);
					for (j=0; j<NUM_VOTOS; j++){
						int id = arrayHijos[i].paisesID[j];
						shmResults[id] = shmResults[id] + arrayHijos[i].votos[j];
					}
				sSignal(sMutex);

				//El hijo se desvincula del buffer
				//debug printf("El hijo se desvincula del Buffer\n");
				shmdt(shmResults);

				//El hijo termina
				//printf("  Hijo %d termina.\n",i); fflush(stdout);
				exit(0);
			}
		} // end for de creación hijos
	  //END TODO ***********************************************

	// Aquí sólo llega el padre, los hijos hacen exit.

  //BEGIN TODO 11 ***********************************************
		//Escribimos la combinación ganadora en el/los pipes de cada hijo
		//Podemos usar la función ComunicarPaises pasándole los parámetros adecuados, 
		//el número de hijo y la lsita de paises a votar que hemos leido del fichero paises.
		for(i=0; i<numHijos; i++){
			//debug printf("El padre comunica por pipe al Hijo[%d] la votacion [%d-%d-%d-%d-%d]\n", i, listaPaisesVotar[i][0], listaPaisesVotar[i][1], listaPaisesVotar[i][2], listaPaisesVotar[i][3], listaPaisesVotar[i][4]);  fflush(stdout);
			//printf("El padre comunica por pipe al Hijo[%d] la votacion [%d-%d-%d-%d-%d]\n", i, listaPaisesVotar[i][0], listaPaisesVotar[i][1], listaPaisesVotar[i][2], listaPaisesVotar[i][3], listaPaisesVotar[i][4]);  fflush(stdout);
			ComunicarPaises(i, listaPaisesVotar[i]);
		}

  //END TODO ***********************************************
		
  //BEGIN TODO 12***********************************************
		//El padre espera a que terminen los hijos.
		//Codificar el bucle para esperar la terminación de los hijos
		//usando la funcion wait o la función waitpid
		//debug printf("El padre espera a la terminacion de los hijos\n");  fflush(stdout);
		int pidE; 
		for(int k=0; k < numHijos; k++){
			pidE=wait(&status); //Esperamos la terminación de cualquier hijo
			//printf("El padre recibe la terminacion del hijo [%d]\n",pidE);  fflush(stdout);
		}
		//debug printf("Los hijos han terminado\n");  fflush(stdout);
  //END TODO ***********************************************
	

  //BEGIN TODO 13***********************************************
		// Aquí sólo llega el padre cuando los hijos ya han terminado.
		// El padre recoge los datos de shmResults y genera un fichero.
		// Para ello, itera por el shmResults para obtener los datos.
		// Cada línea deberá contener el identificador y la puntuación del pais,
		// separado por un espacio en blanco.
		fd = fopen (resultadosFile, "w");
		int dato; 
		for (i=0; i<NUM_PAISES; i++){
			dato=shmResults[i];
			//debug printf("dato[%d]=%d\n",i,dato);
			//Escribe el dato en el fichero
			fprintf(fd, "%d %d\n", i, dato);			
		}
		//Cierra el fichero de resultados
		fclose(fd);
  //END TODO ***********************************************

	//Proceso de cierre.
	//El padre se desvincula del buffer
	//debug printf("El padre se desvincula del Buffer\n");
	shmdt(shmResults);
		
	//El padre borra el buffer
	//debug printf("El padre se destruye los Buffers\n");
	shmctl(shmIdResults, IPC_RMID, 0);

	//El padre destruye el semáforo
	//debug printf("El padre se destruye el Semaforo\n");
	sDestroy(sMutex);

	// El padre termina.
	return 0;
}