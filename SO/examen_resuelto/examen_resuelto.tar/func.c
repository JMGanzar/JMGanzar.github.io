#include <stdio.h>
#include <stdlib.h>
#include <signal.h>   
#include <unistd.h>   
#include <string.h>
#include <sys/types.h>
#include <stdbool.h>
#include <sys/time.h>
#include <ctype.h>
#include "func.h"

extern HIJO *arrayHijos;

//*****************************************************************
//CheckIfFileExists: Comprueba la existencia de un fichero
// filename : nombre del fichero
//*****************************************************************
bool CheckIfFileExists(const char* filename){

	if( access( filename, F_OK ) == 0 ) {
	    // file exists
	    return true;
	} 
	else {
	    // file doesn't exist
	    return false;	
	}
}


//***************************************************
//isNumber : Función que comprueba si una cadena de caracteres es un número
// number  : cadena de caracteres a comprobar
//***************************************************
bool isNumber(char number[])
{
    int i = 0;

    //checking for negative numbers
    if (number[0] == '-')
        i = 1;
    for (; number[i] != 0; i++)
    {
        //if (number[i] > '9' || number[i] < '0')
        if (!isdigit(number[i]))
            return false;
    }
    return true;
}


//***************************************************
//Sintaxis : Vuelca la sintaxis correcta de la llamada
//***************************************************
void Sintaxis(){
	printf("-------------------------------------------------\n");
	printf("Sintaxis del programa:\n");
	printf("procesar <paisesFilename> <resultadosFilename> <numVotantes>\n");
	printf("	paisesFilename      : Nombre del fichero de paises a votar.\n");
	printf("	resultadosFilename  : Nombre del fichero con la puntuacion de los paises.\n");
	printf("	numVotantes         : Numero de hijos. Valores entre [%d:%d]\n",MIN_HIJOS, MAX_HIJOS);
	printf("-------------------------------------------------\n");
}


//***************************************************
//RandInt: Genera un entero aleatorio entre dos valores
// M    : valor bajo del rango de valores
// N    : valor alto del rango de valores
//***************************************************
int RandInt(int M, int N){
	return rand () % (N-M+1) + M;
}


//***************************************************
//ContarLineasFichero: Lee el fichero de texto pasado como parametro 
//  y devuelve el numero de lineas que tiene
// filename         : nombre del fichero 
//***************************************************
int ContarLineasFichero(const char *filename) {
    FILE *fd;
    int nulLineas = 0;
    char buffer[100];

    //BEGIN TODO 1 ****************************************************
        //Abrimos el fichero para solo lectura asignando al descriptor de fichero fd
        fd = fopen(filename, "r");

        //Si ocurre algún problema en la apertura notificamos error y salimos con -1
        if (fd == NULL) {
            perror("Error al abrir el archivo");
            return -1;  // Retornar un valor negativo en caso de error
        }

        // Contamos las lineas del fichero. Nota: Podemos leer lineas con fgets(...)
        while (fgets(buffer, sizeof(buffer), fd) != NULL) {
            nulLineas++;
        }

        // Cerrar el archivo
        fclose(fd);

        //Devolvemos el número de lineas leido
        return nulLineas;
    //END TODO ****************************************************
}




//***************************************************
//LeerFicheroPaises: Lee el fichero de lista de paises
//  a votar y lo guarda en un vector 2D
// filename         : nombre del fichero de paises
// numHijos         : numero de hijos
// listaPaisesVotar : vector 2D donde para cada hijo se guarda
//                    la lista de paises a votar 
//***************************************************
void LeerFicheroPaises(char* filename, int numHijos, int listaPaisesVotar[MAX_HIJOS][NUM_VOTOS]){
	//Abre para lectura el fichero de paises. Si hay error informa y termina
    FILE *file; 

    //BEGIN TODO 2 ****************************************************
        file = fopen(filename, "r");

        if (file == NULL) {
            printf("ERROR: error al abrir el fichero %s\n", filename);
            exit(-1);
        }
    //END TODO ****************************************************

	//Carga el contenido del fichero en el array listaPaisesVotar
    for (int i = 0; i < numHijos; i++) {
        for (int j = 0; j < NUM_VOTOS; j++) {
            //BEGIN TODO 3 ****************************************************
                //Nota, usar if(fscanf ....
                //para cargar el valor leido del fichero en su celda de la matriz, 
                //es decir en &listaPaisesVotar[i][j]
                //si fscanf devuelve -1 es que no se ha podido leer, por ejemplo se está intentando leer más filas de las que hay.
                if (fscanf(file, "%d", &listaPaisesVotar[i][j]) != 1) {
                    fclose(file);
                    printf("ERROR: error al leer la linea %d del fichero %s. Compruebe el parametro numVotantes\n", i, filename);
                    exit(-1);
                }
            //END TODO ****************************************************
        }
    }

    //BEGIN TODO 4****************************************************
    	//Cierra el fichero de paises
    	fclose(file);
    //END TODO ****************************************************
}

//***************************************************
//CrearPipes: Crea los pipes para un determinado número de hijos
// numHijos : número de hijos totales
//***************************************************
void CrearPipes(int numHijos){
	for(int i=0; i<numHijos; i++){
		//Creamos el pipe y lo asignamos al vector correspondiente
		pipe(arrayHijos[i].pipehijo);
	}
}

//***************************************************
//ComunicarPaises: Escribe en un Pipe la lista de
// paises a votar
// numHijo   : identificador del hijo
// idPaises  : vector de IDs de paises
//
//***************************************************
void ComunicarPaises(int numHijo, unsigned int *idPaises){
	close(arrayHijos[numHijo].pipehijo[0]);
	write(arrayHijos[numHijo].pipehijo[1], idPaises, sizeof(int)*NUM_VOTOS);
	close (arrayHijos[numHijo].pipehijo[1]);
}

//***************************************************
//RecibirPaises: Lee de un Pipe la 
// lista de paises a votar
// numHijo   : identificador del hijo
// idPaises  : vector de IDs de paises
//
//***************************************************
void RecibirPaises(int numHijo, unsigned int *idPaises){
	close(arrayHijos[numHijo].pipehijo[1]);
	read(arrayHijos[numHijo].pipehijo[0], idPaises, sizeof(int)*NUM_VOTOS);
	close (arrayHijos[numHijo].pipehijo[0]);
}