#!/bin/bash

ERR_NOT_NUMBER=1
ERR_OUT_OF_RANGE=2

MIN_VOTANTES=10
MAX_VOTANTES=100

MIN_LAUNCHERS=1
MAX_LAUNCHERS=5

MAX_WORKERS=20
MAX_WORKLOAD=5

Number(){
	#----------------------------------
	# NO TOCAR - PODEIS USARLA EN CheckArguments() para determinar si un parámetro  es numérico
	# Parámetros: eimo-
	#    $1 : parametro a comprobar
	# Salida:
	#    1  : si es numérico
	#    0  : si no es numérico
	#----------------------------------
	if [ "$1" -eq "$1" ] 2>/dev/null; then
		return 0
	else
		return 1
	fi
}


Sintaxis(){
	#----------------------------------
	# NO TOCAR
	#----------------------------------
	#Debe de mostrar la sintaxis de uso del programa, con la explicación de los parametros.
	echo "-------------------------------------------------------------------------------------------"
	echo "Sintaxis:"
	echo "lanzar.sh <paisesFilename> <resultadosFilename> <numVotantes>"
	echo ""
	echo "Se generaran los ficheros <paisesFilename> y <resultadosFilename> que "
	echo "se borrarán previamente si existen "
	echo "<numHVotantes> es el numero de hijos que realizan votaciones, puede ser un numero entre $MIN_VOTANTES y $MAX_VOTANTES"
	echo "" 
	echo "-------------------------------------------------------------------------------------------"
}

GenerarCincoNumerosAleatorios() {
	#----------------------------------
	# NO TOCAR
	#----------------------------------
	# Devuelve cinco números enteros aleatorios y no repetidos entre 0 y 25
    numeros=()
    while [ ${#numeros[@]} -lt 5 ]; do
        num=$(( RANDOM % 26 ))
        if [[ ! " ${numeros[@]} " =~ " ${num} " ]]; then
            numeros+=("$num")
        fi
    done
    echo "${numeros[@]}"
}

ConvertirIDaPAIS(){
	#----------------------------------
	# NO TOCAR
	#----------------------------------
	#A partir del identificador de pais (0-25), devuelve el nombre del pais correspondiente.
	local id=$1
    local paises=("Albania" "Alemania" "Armenia" "Australia" "Austria" "Belgica" "Chequia" "Chipre" "Croacia" "Eslovenia" 
                  "Espana" "Estonia" "Finlandia" "Francia" "Italia" "Lituania" "Moldavia" "Noruega" "Polonia" "Portugal" 
                  "Reino Unido" "Rumania" "Serbia" "Suecia" "Suiza" "Ucrania")

    echo "${paises[$id]}"
}

#***************************************************************************
# Completar las siguientes funciones según el enunciado y los comentarios.
#***************************************************************************
 
ShowResults(){
	# Esta función ordena el archivo de salida del programa C (que recibe como argumento), de mayor a menor
	# puntuación, generando un nuevo archivo de puntuaciones ordenado. 
	# Después, lee el nuevo fichero de puntuaciones ordenado y muestra por pantalla los resultados, 
	# mostrando el nombre del país seguido de su puntuación obtenida.

  #BEGIN TODO 1 *******************************************************
		# Se comprueba que el fichero de resultados existe, si no existe, se muestra error y salimos con -1.
		if ! [ -f "$1" ]; then
			echo "El fichero $1 no existe"
			exit -1
		fi
  #END TODO *******************************************************

  #BEGIN TODO 2 *******************************************************
		# Se genera el fichero ordenado según el valor de la segunda columna y se guarda con el mismo nombre acabado con _sort
		sort -n -r -k 2 $1 > ${1}_sort
  #END TODO *******************************************************

  #BEGIN TODO 3 *******************************************************
		# Lee el archivo de resultados ordenado, y mientras lo recorre, muestra por pantalla el resultado:
		echo "# Resultados de la votación:"
		while IFS= read -r line; do
			idPais=`echo $line | cut -f1 -d ' '`
			puntos=`echo $line | cut -f2 -d ' '`
			pais=$(ConvertirIDaPAIS $idPais)

			echo "$pais - $puntos puntos"
		done < ${1}_sort
  #END TODO *******************************************************
}

CheckArguments(){
	# Funcion para validar los argumentos pasados al script.

  #BEGIN TODO 4 *******************************************************
		#Para sacar Sintaxis cuando no me pasan argumentos.
		if [ $# -eq 0 ]; then
			Sintaxis
			exit 0
		fi

		#Comprobamos que el número de parametros es 3
		if [ $# -ne 3 ]; then
			echo "Error número de parametros incorrecto ($#), debe ser 3."
			Sintaxis
			exit 1
		fi

		#Comprobamos que el paramatro $1 es un string (no es numerico)
		if Number $1 ; then
			echo "El parametro <paisesFilename> debe ser un string."
			Sintaxis
			exit 1
		fi

		#Comprobamos que el paramatro $2 es un string (no es numerico)
		if Number $2 ; then
			echo "El parametro <resultadosFilename> debe ser un string."
			Sintaxis
			exit 1
		fi

		#Comprobamos que el parámetro $3 es un número 
		if ! Number $3 ; then
			echo "El parámetro <numVotantes> ($3) debe ser un número"
			Sintaxis
			exit 1
		fi

		#Comprobamos el rango del parámetro numHijos
		if [ $3 -lt $MIN_VOTANTES ] || [ $3 -gt $MAX_VOTANTES ] ; then
			echo "El parametro <numVotantes> debe estar en el intervalo [$MIN_VOTANTES..$MAX_VOTANTES]"
			Sintaxis
			exit 1
		fi
  #END TODO *******************************************************
}

GenerarListadoPaises() {
	# Genera un archivo donde se almacenará el listado de países que votará cada hijo.
	# El archivo contendrá tantas líneas como hijos hayan configurados. Cada línea
	# constará de 5 números aleatorios, enteros y no repetidos, entre 0 y 25
    local paisesFilename=$1
    local hijos=$2

  	#BEGIN TODO 5 *******************************************************
	    # Crear el archivo y agregar los números aleatorios
	    for (( i = 0; i < hijos; i++ )); do
	        numeros=$(GenerarCincoNumerosAleatorios)
	        echo "$numeros" >> "$paisesFilename"
	    done
  #END TODO *******************************************************
}

#----------------------------------------------
# MAIN
#----------------------------------------------

#Comprobar los argumentos llamando a CheckArguments apropiadamente
CheckArguments $*

paisesFilename=$1
resultadosFilename=$2
numHijos=$3

#Si los parametros $1 o $2 son ficheros que exiten los tenemos que borrar. 
#Sacamos un mensaje por pantalla diciendo de que se ha borrado. Pero no mostramos error.

#BEGIN TODO 6 *******************************************************
	#Borramos el fichero <paisesFilename> e informamos
	if [ -f "$paisesFilename" ]; then
		rm $paisesFilename > /dev/null
		echo "El fichero [$paisesFilename] se ha borrado."
	fi

	#Borramos el fichero <resultadosFilename> e informamos
	if [ -f "$resultadosFilename" ]; then
		rm $resultadosFilename > /dev/null
		echo "El fichero [$resultadosFilename] se ha borrado."
	fi

	#Borramos el fichero <resultadosFilename_sort> e informamos
	if [ -f "${resultadosFilename}_sort" ]; then
		rm ${resultadosFilename}_sort > /dev/null
		echo "El fichero [${resultadosFilename}_sort] se ha borrado."
	fi

#END TODO *******************************************************

# Generamos el archivo de listado de paises
GenerarListadoPaises $paisesFilename $numHijos

# Llamamos al proceso de C con los parametros adecuados
./procesar $paisesFilename $resultadosFilename 

# Leemos y mostramos por pantalla los resultados
ShowResults $resultadosFilename
