#!/bin/bash

MODO_ABRIR=0
MODO_RESULTADOS=1

MAX_ASISTENTES=10000

Number(){
	#----------------------------------
	# NO TOCAR - PODEIS USARLA EN CheckArguments() para determinar si un parámetro  es numérico
  # ATENCION - Para capturar un return teneis que obtener el resultado o bien usando un subshell o bien con #?
	# Parámetros: 
	#    $1 : parametro a comprobar
	# Salida:
	#    1  : si es numérico
	#    0  : si no es numérico
	#----------------------------------
	if [ "$1" -eq "$1" ] 2>/dev/null; then
		return 0  # Es correcto, debe ser 0
	else
		return 1  # Es correcto, debe ser 1
	fi
}


Sintaxis(){
	#----------------------------------
	# NO TOCAR
	#----------------------------------
	#Debe de mostrar la sintaxis de uso del programa, con la explicación de los parametros.
	echo "-------------------------------------------------------------------------------------------"
	echo "Sintaxis:"
	echo "MODO ABRIR CINES:"
	echo "  cine.sh -f configFilename -n numAsistentes"
	echo "            configFilename : Fichero de configuracion con una linea por cada sala de cine"
	echo "                             El numero en la linea indica el aforo maximo de la sala"
	echo "            numAsistentes  : Numero de asistentes que entrarán hoy en el centro comercial"
	echo "                             Debe ser mayor que la suma de los aforos máximos de todas las salas de cine"
	echo "                             Si no es mayor informamos del error en el paso de parametros"
	echo "             Se llama a proyectar (parte C) con estos parametros "
	echo ""
	echo "MODO RESULTADOS:"
	echo "  cine.sh <orden>"
	echo "            <orden> : Modo de ordenacion de los resultados"
	echo "                      Puede ser -s : ordena los resultados mostrados por salas"
	echo "                                -v : ordena los resultados mostrados por proyecciones"
	echo "                                -V : ordena los resultados mostrados por asistentes totales"
	echo "   Se lee el fichero de resumen registro.dat"
	echo "   Se presentan los datos en función del parametro orden."
	echo "   En cualquiera de los modos se pide que se indique cual es la sala más demandada"
	echo "-------------------------------------------------------------------------------------------"
}

ObtenerAforoCentroComercial(){
  # Esta función lee las lineas del fichero de configuración, que recibe como parametro 
  # y las suma para calcular el aforo completo de todos los cines del centro comercial.
  # Devuelve con echo el aforo total sumado.
  # Lee el archivo de resultados ordenado, y mientras lo recorre, muestra por pantalla el resultado:
    local archivo="$1"
    local suma=0

    #BEGIN TODO 1 ****************************************************************************
      # Verificar si el archivo existe
      if [ ! -f "$archivo" ]; then
          echo "Error: Obtener Aforo: El archivo no existe: $archivo"
          exit -1
      fi

      # Leer el archivo línea por línea y sumar los números
      while read -r linea; do
          # Validar si la línea es un número
          if ( Number $linea ); then 
              suma=$((suma + linea))
          else
              echo "Error: Obtener Aforo: El archivo tiene líneas no numericas."
              exit -1
          fi
      done < "$archivo"

      #Mostramos con echo la suma 
      echo $suma
    
    #END TODO 1 ****************************************************************************
}

CheckArguments(){
	# Funcion para validar los argumentos pasados al script.
  modo=-1

  #BEGIN TODO 2 ****************************************************************************
    #Si no nos pasan argumentos mostramos error, Sintaxis y salimos
    if [ $# -eq 0 ]; then
      echo "Faltan los parametros"
      Sintaxis
      exit 0
    fi

    #Comprobamos que el primer parametro es un string (no es numerico)
    if ( Number $1 ); then
      echo "Error: El primer parametro debe ser un string."
      Sintaxis
      exit 1
    fi

    # Si el primer parámetro empieza por -f estamos en MODO ABRIR CINES. 
    #   En ese caso se realizan las siguientes comprobaciones y acciones. Si no, Sintaxis y salir. 
    #     Comprobamos que el numero de parametros es 4
    #     Comprobamos que el segundo parametro es un string. Se asigna la variable configFilename al valor leido.
    #     Comprobamos que el tercer parametro es -n
    #     Comprobamos que el cuarto parametro es numerico. Se asigna la variable numAsistentes al valor leido
    #     Comprobamos que el numAsistentes es menor que MAX_ASISTENTES
    #     Asignamos la variable modo a MODO_ABRIR
    # Si no, si el primer parametro es -s, -v o -V estamos en MODO RESULTADOS. 
    #   En ese caso se realizan las siguientes comprobaciones y acciones. Si no, Sintaxis y salir. 
    #     Comprobamos que el numero de parametros es 1.
    #     Asignamos la varialbe modo a MODO_RESULTADOS
    #     Asignamos el parametro leido (-s, -v, -V) a la variable orden
    # Si no, informar que hay un error, Sintaxis y salir.
    if [ "$1" == "-f" ]; then
      # Comprobamos que el numero de parametros es 4
      if [ $# -ne 4 ]; then
        echo "Error número de parametros incorrecto ($#), debe ser 4 para el MODO ABRIR CINES."
        Sintaxis
        exit 1
      fi

      #Comprobamos que el segundo parametro es un string. En caso de error, Sintaxis y salir.
      if ( Number $2 ); then
        echo "Error, el parametro configFilename debe ser un string."
        Sintaxis
        exit
      else
        #Asignamos el nombre del fichero de configuracion
        configFilename=$2
      fi

      #Comprobamos que el tercer parametro es -n .  En caso de error, Sintaxis y salir.
      if [ "$3" != "-n" ]; then
        echo "Error, el tercer parametro debe ser -n en el modo abrir."
        Sintaxis
        exit 1
      fi

      #Si el cuarto parametro no es numerico de error, Sintaxis y salir.
      #sino comprobamos si es mayor que el MAX_ASISTENTES en cuyo caso, error Sintaxis y salir
      #sino asignamos a la variable numAsistentes el parametro
      if ( ! Number $4 ); then
        echo "Error, el parametro numAsistentes debe ser un numerico."
        Sintaxis
        exit 1
      elif [ $4 -gt $MAX_ASISTENTES ]; then
        echo "Error, el parametro numAsistentes debe ser menor que $MAX_ASISTENTES"
        Sintaxis
        exit -1
      else
        #Asignamos la variable numAsistentes
        numAsistentes=$4
      fi

      #Establecemos el modo a MODO_ABRIR
      modo=$MODO_ABRIR

    elif [ "$1" == "-s" ] || [ "$1" == "-v" ] || [ "$1" == "-V" ]; then
      #Estamos en modo Resultados no puede haber mas parametros
      #Comprobamos que el numero de parametros es 1 
      if [ $# -ne 1 ]; then
        echo "Error número de parametros incorrecto ($#), debe ser 1 para el modo resultados."
        Sintaxis
        exit 1
      fi

      #Asignamos la variable modo a MODO_RESULTADOS
      modo=$MODO_RESULTADOS

      #Asignamos el parametro $1 a la variable orden
      orden=$1

    else 
      #Indicamos error Sintaxia y salir
      echo "Error. No es el modo correcto."
      Sintaxis
      exit 1

    fi
  #END TODO 2 ****************************************************************************
 
}

#----------------------------------------------
# MAIN
#----------------------------------------------

#Comprobar los argumentos llamando a CheckArguments apropiadamente
CheckArguments $*


#BEGIN TODO 3 ****************************************************************************
  #Mostramos el modo de trabajo y los parametros
  if [ $modo -eq $MODO_ABRIR ]; then  
    printf "Modo=ABRIR_CINES fileName=%s numAsistentes=%d\n" "$configFilename" "$numAsistentes"
  elif [ $modo -eq $MODO_RESULTADOS ]; then
    if [ "$orden" == "-s" ]; then
      strOrden="Salas"
    elif [ "$orden" == "-v" ]; then
      strOrden="Proyecciones"
    elif [ "$orden" == "-V" ]; then
      strOrden="Asistentes"
    fi
    printf "Modo=RESULTADOS orden=$strOrden\n" "$strOrden"
  fi
#END TODO 3 ****************************************************************************

#En función del modo realizamos las acciones


#BEGIN TODO 4 ****************************************************************************
#Si el modo es MODO_ABRIR 
  if [ $modo -eq $MODO_ABRIR ]; then
    #Lanzamos el programa proyectar habiendo comprobado antes 
    #si el numero de asistentes es mayor estricto que el aforo total del centro comercial.
    #Leemos el fichero de configuración sumando las lineas para tener el total de asistentes al centro 
    #comercial y poder comparar con el parametro numAsistentes. Podemos usar la función ObtenerAforoCentroComercial

    #Obtenemos el aforoTotal del centro comercial.
    aforoTotal=$(ObtenerAforoCentroComercial $configFilename)
    echo "El aforo total del centro comercial es $aforoTotal"

    #Comprobamos que el aforoTotal es menor que el numero de asistentes que nos pasan.
    if [ $numAsistentes -le $aforoTotal ]; then
      echo "Error: El numero de asistentes [$numAsistentes] debe ser mayor que el aforo total [$aforoTotal]"
      exit -1
    fi

    #Antes de lanzar la ejecución borramos el fichero registro.dat con los resultados anteriores si lo hubiera
    rm registro.dat 2>/dev/null

    #Procedemos a lanzar el ejecutable proyectar con los parametros correctos.
    ./proyectar $configFilename $numAsistentes
  fi
#END TODO 4 ****************************************************************************

#BEGIN TODO 5 ****************************************************************************
#Si el modo es MODO_RESULTADOS leemos el fichero de registro y lo presentamos según el orden solicitado.
if [ $modo -eq $MODO_RESULTADOS ]; then
    #Generamos un fichero temporal ordenando por la columna adecuada en función del orden solicitado.
    sortedFilename="sorted_registro.dat"

    # Se genera el fichero ordenado descendentemente según el orden pedido. Se guarda con el nombre elegido en sortedFilename. 
    # Las columnas del fichero registro.dat generado por proyectar son "Salas", "Proyecciones" y "Numero de Asistentes"
    # Podemos crear una variable sortColumn para determinar la columna por la que ordenar para el comando sort
    if [ "$orden" == "-s" ]; then 
       sortColumn=1
    elif [ "$orden" == "-v" ]; then
       sortColumn=2
    elif [ "$orden" == "-V" ]; then
       sortColumn=3
    fi
    
    # Generamos el fichero temporal ordenado descendentemente por la columna correcta
	  sort -n -r -k $sortColumn registro.dat > $sortedFilename

    #Leemos el fichero temporal ordenado mostrando los resultados, según leemos el fichero los siguientes mensajes para cada línea.
    #Si el orden es por salas mostraremos "La sala A ha realizado B proyecciones con un total de C asistentes" donde A, B, C son los datos apropiados.
    #Si el orden es por numero de proyecciones mostraremos "Se han realizado B proyecciones en la sala A con un total de C asistentes" donde A, B, C son los datos apropiados.
    #Si el orden es por numero de asistentes mostraremos "C asistentes han usado la sala A en B proyecciones"
    #Podéis hacerlo directamente aquí o crear una función para realizar esta tarea.
    echo "# Resumen del día :"
    while IFS= read -r line; do
      #Obtenemos los datos de la linea
      sala=`echo $line | cut -f1 -d ' '`
      proyecciones=`echo $line | cut -f2 -d ' '`
      asistentes=`echo $line | cut -f3 -d ' '`

      #En funcion del orden mostramos el texto que se indica en el comentario anterior.
      if [ "$orden" == "-s" ]; then 
        echo "La sala $sala ha realizado $proyecciones proyecciones con un total de $asistentes asistentes"
      elif [ "$orden" == "-v" ]; then
        echo "Se han realizado $proyecciones proyecciones en la sala $sala con un total de $asistentes asistentes" 
      elif [ "$orden" == "-V" ]; then
        echo "$asistentes asistentes han usado la sala $sala en $proyecciones proyecciones"
      fi
    done < $sortedFilename
fi
#END TODO 5 ****************************************************************************
