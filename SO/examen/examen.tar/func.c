#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>   
#include <string.h>
#include <sys/types.h>
#include <stdbool.h>
#include <sys/time.h>
#include <ctype.h>
#include <signal.h>   
#include "func.h"

extern SALA *arraySalas;
extern int salasAbiertas;

//*****************************************************************
//ContadorSalasAbiertas: Funcion manejadora para señal en tiempo real
//*****************************************************************
void ContadorSalasAbiertas(int sig, siginfo_t *siginfo, void *context){
    //BEGIN TODO 1 ****************************************************************
        // Esta función es el manejador de señales en tiempo real.
        // Cada sala enviará al padre una señal diciendo que se ha abierto al publico
        // Aquí contaremos cuantas salas han abierto en una variable global, salasAbiertas.
        salasAbiertas++;
    //END TODO 1 ****************************************************************
}

//*****************************************************************
//AperturaSala: envio de señal en tiempo real (solo usado por salas)
//*****************************************************************
void AperturaSala(){
    //BEGIN TODO 2 ****************************************************************
        // Esta función la utilzaran las salas de cine para enviar una señal en tiempo real al padre 
        // de forma que éste sepa que la sala se ha abierto al público.
        // Asignamos los datos correctos a la unión sigval v
        // y enviamos la señal utilizando sigqueue al padre.
        union sigval v;
        // asignamos el pid del proceso que envia.
        v.sival_int = getpid(); 
        // enviamos la señal de tiempo real SIGRTMIN
        sigqueue(getppid(),SIGRTMIN,v); 
    //END TODO 2 ****************************************************************
}

//***************************************************
//CREAR PIPES : Función que crea los pipe para los hijos dado el array de hijos
//              Devuelve el numero de pipes creados si se crean correctamente el array
//              o -1 en caso de error
//***************************************************
int CrearPipes(int numSalas){
	int i; 
	int retVal=numSalas;
    //BEGIN TODO 3 ****************************************************************
        // Creación de los pipes de comunicación con los hijos.
        // Creamos en bucle un pipe para cada sala en el campo de su estructura.
        // Tenemos un arraySalas con una estructura SALA (ver func.h) para cada sala de cine
        // Si alguno de los pipes no se puede crear actualizamos retVal=-1, forzamos la salida del bucle y retornamos retVal
        for(i=0; i < numSalas; i++) { 
            if (pipe(arraySalas[i].pipe) == -1) {
                retVal=-1;
                break; 
            }
        }	
    //BEGIN TODO 3 ****************************************************************
	return retVal; 
}

//***************************************************
//LECTURA DE UN ENTERO DE UN PIPE 
//      fdPipe     : descriptor del pipe del que leer
// retorna
//      dato       : entero leido del pipe
//***************************************************
int LeerPipe(int fdPipe){
	int dato,n;
    //BEGIN TODO 4 **************************************************************
        //Leemos un entero del pipe que nos pasan como parametro.
        n=read(fdPipe, &dato, sizeof(int));
    //END TODO 4 ****************************************************************
    //Devolvemos el dato (entero) leido
    return dato; 
}

//***************************************************
//ESCRITURA DE UN ENTERO EN UN PIPE 
// fdPipe     : descriptor del pipe en el que escribir
// dato       : entero a ecribirlos en el pipe
//***************************************************
void EscribirPipe(int fdPipe, int dato){
    //BEGIN TODO 5 **************************************************************
        //Escribimos en el pipe que nos pasan el dato entero que tambien recibimos
        write(fdPipe, &dato, sizeof(int));
    //END TODO 5 ****************************************************************
}


//********************************
// El resto de funciones NO TOCAR.
//********************************

//*****************************************************************
//CheckIfFileExists: Comprueba la existencia de un fichero
// filename : nombre del fichero
//*****************************************************************
bool CheckIfFileExists(const char* filename){

	if( access( filename, F_OK ) == 0 ) {
	    // file exists
	    return true;
	} 
	else {
	    // file doesn't exist
	    return false;	
	}
}


//***************************************************
//isNumber : Función que comprueba si una cadena de caracteres es un número
// number  : cadena de caracteres a comprobar
//***************************************************
bool isNumber(char number[])
{
    int i = 0;

    //checking for negative numbers
    if (number[0] == '-')
        i = 1;
    for (; number[i] != 0; i++)
    {
        //if (number[i] > '9' || number[i] < '0')
        if (!isdigit(number[i]))
            return false;
    }
    return true;
}


//***************************************************
//Sintaxis : Vuelca la sintaxis correcta de la llamada
//***************************************************
void Sintaxis(){
	printf("-------------------------------------------------\n");
	printf("Sintaxis del programa:\n");
	printf("proyectar <configFilename> <numAsistentes>\n");
	printf("	configFilename  : Nombre del fichero de configuracion del centro comercial.\n");
	printf("	numAsistentes   : Numero de asistentes que entran hoy a las salas de cine del contro comercial.\n");
	printf("-------------------------------------------------\n");
}


//***************************************************
//RandInt: Genera un entero aleatorio entre dos valores
// M    : valor bajo del rango de valores
// N    : valor alto del rango de valores
//***************************************************
int RandInt(int M, int N){
	return rand () % (N-M+1) + M;
}


//***************************************************
//ContarLineasFichero: Lee el fichero de texto pasado como parametro 
// y devuelve el numero de lineas que tiene
// filename         : nombre del fichero
//***************************************************
int ContarLineasFichero(const char *filename) {
    FILE *fd;
    int nulLineas = 0;
    char buffer[100];

    //Abrimos el fichero para solo lectura asignando al descriptor de fichero fd
    fd = fopen(filename, "r");

    //Si ocurre algún problema en la apertura notificamos error y salimos con -1
    if (fd == NULL) {
        perror("Error al abrir el archivo");
        return -1;  // Retornar un valor negativo en caso de error
    }

    // Contamos las lineas del fichero
    while (fgets(buffer, sizeof(buffer), fd) != NULL) {
        //values[nulLineas] = atoi(buffer);
        nulLineas++;
    }

    // Cerrar el archivo
    fclose(fd);

    //Devolvemos el número de lineas leido
    return nulLineas;
}


//***************************************************
//CrearResumenProyecciones: Función para crear o añadir al fichero de resumen registro.dat
//                    Cada sala lo llamara para añadir sus resultados al fichero
// numSala          : numero de la sala que la llama
// numProyeccion    : numero de proyección correspondiente de la sala
// numAsistentes    : numero de asistentes totales que han visto la proyección
//***************************************************
void CrearResumenProyecciones(int numSala, int numProyeccion, int numAsistentes){
    FILE *fd; 
    char resumenFile[50] = "registro.dat";

    //Abrimos el el fichero para "append" y escribimos una sola línea con numSala, numProyeccion y numAsistentes
    //separados por un espacio y cerramos el fichero
    fd = fopen (resumenFile, "a");
    fprintf(fd, "%d %d %d\n", numSala, numProyeccion, numAsistentes);
    fclose(fd);
}


//***************************************************
//LeerAforoSala: Función para leer el aforo de la sala de cine numSala desde un archivo 
//                   pasado, donde cada linea tiene un numero.
// filename    : nombre del fichero de configuracion
// numSala     : numero de la sala de la que obtener el aforo
// Retorno:
//    Devuelve el aforo de esa sala de cine
//***************************************************
int LeerAforoSala(const char *filename, int numSala){
    FILE *fd;
    int numero;
    int contador = 0;

    fd = fopen(filename, "r");

    if (fd == NULL) {
        perror("Error al abrir el archivo");
        return -1;  // Retornar un valor negativo en caso de error
    }

    // Leer números desde el archivo y almacenarlos en el array
    while (fscanf(fd, "%d", &numero) == 1 && contador < numSala) {
        contador++;
    }

    // Cerrar el archivo
    fclose(fd);

    return numero; 
}

//***************************************************
//LanzarProyeccion: Función que simula la proyección o pase de una película.
// numSala          : indice de la sala que lanza el pase
// numProyeccion    : numero de proyección que está lanzando la sala
// numAsistentes    : numero de asistentes de dicha proyección
//***************************************************
void LanzarProyeccion(int numSala, int numProyeccion, int numAsistentes){
    int duracion = RandInt(1,2); //Simula la duración aleatoria de la película
    printf("Sala [%d] lanza la proyección [%d] para [%d] asistentes\n", numSala, numProyeccion, numAsistentes); fflush(stdout);
    sleep(duracion); 
}
