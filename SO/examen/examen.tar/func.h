#define MAX_SALAS 10

#define CANAL_LECTURA 0
#define CANAL_ESCRITURA 1

#define ULTIMO_PASE -1

typedef struct { 
    int pid ;    // Pid de la atraccion 
    int aforo;   // Numero maximo de asistentes en una proyección
    int pipe[2]; // Descriptores del pipe
} SALA ;

int  RandInt(int M, int N);
void ContadorSalasAbiertas(int sig, siginfo_t *siginfo, void *context);
void AperturaSala();
bool CheckIfFileExists(const char* filename);
bool isNumber(char number[]);
void Sintaxis();
int  ContarLineasFichero(const char *filename);
void CrearResumenProyecciones(int numAtraccion, int numViajes, int numViajeros);
int  LeerAforoSala(const char *filename, int numAtraccion);
int  CrearPipes(int numSalas);
int  LeerPipe(int fdPipe);
void EscribirPipe(int fdPipe, int dato);
void LanzarProyeccion(int atraccion, int viaje, int numViajeros);
