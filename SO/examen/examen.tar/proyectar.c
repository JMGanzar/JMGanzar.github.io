#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <stdbool.h>
#include <sys/wait.h>
#include "func.h"
#include "sem.h"

#define SSEED 99           //Semilla para el Semaforo
#define SHMSEED 35         //Semilla para la asignacion del segmento de memoria compartida
#define SHMPERMISOS 0644   //Permisos para el segmento de memoria compartida

// Definimos un Array global de salas de cine.
// Se reservará dinamicamente la memoria para este array cuando sepamos cuantas salas de cine vienen en el fichero config.
SALA *arraySalas; 

//Contador de salas de cine abiertas, que se actualizará en el manejador de la señal que llega de los hijos.
int salasAbiertas = 0;

// Programa principal ------------MAIN------------ ------------MAIN------------ ------------MAIN------------ ------------MAIN------------
int main(int argc, char *argv[]){
//Declaramos las variables necesarias para la memoria compartida.
	int shmIdAforos; // Id del segmento de memoria compartida
	int shmAforosSize;  // Tamaño del segmento de memoria compartida
	int *shmAforos;  // Puntero al inicio del semgento de memoria compartida

 	//Declaramos el semaforo mutex de acceso a la memoria compartida
	int sMutex;

	int pidT, pidS; // Para almacenar los PIDs de la taquilla (padre) y salas (hijos)
	int i,j;        // iteradores genericos para bucles
	int numSalas;   // Para el numero de salas de cine (hijos)

	// Vector para almacenar el aforo de las salas de cine.
	// Lo dimensionamos para el número maximo de salas de cine.
	int listaAforos[MAX_SALAS];

	int status;           // Para status de retorno de la llamada al sistema wait
	char buffer[200]="";  // Buffer genérico para llamadas al sistema write/read
 	FILE * fd;            // Descriptor de fichero para usarlo para fichero de resultados
	char configFile [100]= ""; //Para el nombre del fichero de listas de paises a votar generado en bash
	int totalAsistentes;  // Numero total de asistentes que entran al centro comercial en el dia

	//BEGIN TODO 1 ******************************************************************
		//Control de paraḿetros y asignación a variables
		//Si error mostramos mensaje, sintaxis y terminamos con -1
		//Controlamos el numero de parametros. Se esperan 2.
		if(argc != 3){
			printf("ERROR: error en el numero de parametros [%d], se esperaban %d.\n",argc-1,2);
			Sintaxis();
			exit(-1);
		}
		
		//Capturamos los datos  en las variables correspondientes
		// configFile      <-- argv[1] (string)
		// totalAsistentes <-- argv[2] (entero)
		strcpy(configFile, argv[1]);
		totalAsistentes = atoi(argv[2]);

		//Comprobamos si el fichero de configFile del centro comercial existe. Si no existe, mostramos error y salimos.
		//Podemos usar la función CheckIfFileExists definida en func.h
		if (CheckIfFileExists(configFile) == 0){
			printf("ERROR: el fichero [%s] no existe.\n",configFile);
			Sintaxis();
			exit(-1);
		}
	//END TODO 1 ******************************************************************

	//BEGIN TODO 2 ******************************************************************
		//Se define la estructura para el manejador de las señales que recibe el padre
		struct sigaction manejador;

		// Se inicializa el contador de mensajes recibidos, que han sido enviados por los hijos, (las salas), que indican que han abierto.
		
		//Nombre de la funcion manejadora de las señales de tiempo real que enviaran los hijos
		manejador.sa_sigaction = ContadorSalasAbiertas;

		//Informacion adicional SA_SIGINFO junto a la señal
		manejador.sa_flags = SA_SIGINFO; 

		//Establecemos el manejador de la señal a la función manejadora
		sigaction(SIGRTMIN, &manejador , NULL);
	//END TODO 2 ******************************************************************

	
	//BEGIN TODO 3 ******************************************************************
		//Leemos del fichero de configuracón el número de líneas del fichero configFile para ver cuantos hijos hay que crear.
		//Podemos usar la funcion ContarLineasFichero
		numSalas = ContarLineasFichero(configFile);
		printf("En este centro comercial hay %d salas de cine\n",numSalas);
		if (numSalas == -1){
			printf("ERROR: no se ha podido abrir el fichero [%s].\n",configFile);
			exit(-1);
		}

		// Ahora que sabemos cuantas salas de cine hay, podemos dimensionar el array de salas.
		// Creamos el array de estructuras para las salas de cine de forma dinámica
		arraySalas = (SALA*)malloc(numSalas*sizeof(SALA));

		// Creamos la memoria compartida.
		// Definimos el tamaño, creamos el segmento de memoria compartida shmAforos y asignamos correctamente los punteros.
		// Si Error mostramos mensaje y salimos
		shmAforosSize = numSalas*sizeof(int);

		shmIdAforos = shmget(ftok("./", SHMSEED), shmAforosSize, IPC_CREAT | SHMPERMISOS);
		if (shmIdAforos==-1){
			printf("ERROR: error al crear el segmento de memoria compartida\n");
			exit(1);
		}

		//Apuntamos shmAforos a la memoria compartida reservada
		shmAforos = shmat(shmIdAforos,0,0);



		// La capacidad máxima que tiene cada sala la cargará la propia sala antes de abrir al público.
		// El padre la desconoce, pero la leera del array shmAforos
		// Inicializamos el vector shmAforos con ceros
		for (int s=0; s<numSalas; s++){
			shmAforos[s] = 0;
		}


		//Creamos el semáforo mutex de acceso al vector de resultados inicializado a sus valor correcto
		//Inicializar para que el primer proceso que llegue entre
		sMutex = sCreate(SSEED,1);  


		// Llamamos a la funcion CrearPipes para que se cree un Pipe por cada hijo
		int pipesCreados = CrearPipes(numSalas);
		if (pipesCreados != numSalas){
			printf("Error al crear los pipes\n");
			exit(-1);
		}
	//END TODO 3 ******************************************************************

	// Guardamos el PID de la taquilla (padre) en pidT.
	pidT = getpid();

	//BEGIN TODO 4 ******************************************************************
		//---************ BUCLE PARA CREAR LOS HIJOS (SALAS)************---
		// El padre crea en bucle las salas de cine. A su vez, se encargará de distribuir a los asistentes por
		// las diferentes salas de forma aleatoria, según disponibilidad (vector shmAforos).
		// Cada sala de cine irá recibiendo por Pipe el número de asientos comprados. Cuando la sala se complete,
		// dejará de sentar a la gente y lanzará un una proyección de la película, simulado con un sleep. 
		// Después, volvera a indicar que el aforo está completo para que puedan seguir vendiendo entradas de esa sala.
		
		// // El padre itera creando las salas de cine
		for (i = 0; i < numSalas; i++) { 
			// ATENCION: La variable i es el índice de la sala, procurad no usarla para otra cosa.
	
			// llamamos a la funcion fork obteniendo en la variable pidS el valor retornado
			pidS = fork();
	
			// Si no se ha podido crear al hijo (sala) mostramos error y salimos con -1
			if (pidS == -1)	{
				sprintf(buffer, "ERROR. Fork ha fallado al crear la sala de cine %d\n", i);fflush(stdout);
				perror(buffer);
				exit(-1);
			}

			// Determinamos si el pid es del padre o de un hijo
			if (pidS != 0){ 
				// CODIGO DEL PADRE (TAQUILLA) CODIGO DEL PADRE (TAQUILLA) CODIGO DEL PADRE (TAQUILLA) CODIGO DEL PADRE (TAQUILLA) CODIGO DEL PADRE (TAQUILLA)
				// mantenimiento de la estructura de hijos, almacenamos el PID de la sala de cine en su campo correspondiente
				arraySalas[i].pid = pidS;

				// Cerramos el canal de lectura de los pipes
				close(arraySalas[i].pipe[CANAL_LECTURA]);
			}
			else{ 
				// CODIGO HIJO (SALA) CODIGO HIJO (SALA) CODIGO HIJO (SALA) CODIGO HIJO (SALA) CODIGO HIJO (SALA) CODIGO HIJO (SALA)
				//Inicializamos el generador de numeros aleatorios diferente para cada hijo en función de su pid
				srand(getpid());

				// Cerramos el canal de escritura del pipe
				close(arraySalas[i].pipe[CANAL_ESCRITURA]);

				// Definimos la variable contador de número de proyecciones
				int numProyecciones = 0; 

				// La sala tiene que saber cuál es su aforo máximo, para restablecerlo tras una proyección.
				// Esta es una variable privada de cada hijo (sala) que se carga desde el fichero de configuracion con la funcion LeerAforoSala
				int aforoMaximo = LeerAforoSala(configFile,i);
			
				//El hijo actualiza su aforo maximo en el array compartido en exclusion mutua
				sWait(sMutex);
					shmAforos[i]=aforoMaximo;
				sSignal(sMutex);

				printf("  Sala [%d] - Abro con un aforo máximo de [%d] asientos.\n", i, aforoMaximo);fflush(stdout);

				// Comunicamos mediante señal que la Sala esta abierta al público. Tenemos una funcion definida en func.h para ello.
				AperturaSala();

				int asistentes_nuevos = 0;
				int asientos_libres = aforoMaximo;
				int asistentes_sentados = 0;
				int asistentes_totales = 0; 

				// La sala de cine lee del Pipe cuantos asistentes entran inicialmente.
				// Si se ha completado el aforo de la sala se hace una proyección o pase de la película, incrementa el numero de proyecciones y asistentes totales
				// Cuando termina la proyección se vuelve a restablecer el aforo de la sala.
				// Si no se ha llenado el aforo la sala vuelve a esperar en el pipe a que le digan cuantos asistentes más entran.
				// Si lo que recibe del Pipe es el token ULTIMO_PASE la sala hace la proyección o pase tras el cual terminará, incrementa el numero de proyecciones y asistentes totales.
				// vamos paso a paso...

				// La sala lee del pipe el número de asistentes que entran. Hay funciones para ello definidas en func.h
				asistentes_nuevos = LeerPipe(arraySalas[i].pipe[CANAL_LECTURA]);

				// Inicializamos la variable booleana lanzarProyeccion a falso.
				bool lanzarProyeccion = false; 
				
				//Mientras no recibamos el token ULTIMO_PASE (ver func.h) lo que llega son los asistentes nuevos.
				while (asistentes_nuevos != ULTIMO_PASE){
					//Actualizamos los asientos libres (ver definición mas arriba), restando los asistentes nuevos.
					asientos_libres -= asistentes_nuevos;

					//Si no quedan asientos libres se lanza la proyección
					if (asientos_libres == 0){
						lanzarProyeccion=true;
					}

					// Si hay que lanzar la proyección
					if (lanzarProyeccion){
						// Incrementamos el numero de proyecciones de esta sala
						numProyecciones++;

						// Como no quedan asientos libres los asistentes_sentados son igual al aforo maximo
						asistentes_sentados = aforoMaximo;

						// Incrementamos el numero de asistentes totales con los que hay sentados 
						asistentes_totales += asistentes_sentados;

						// Se lanza la proyección de la película, con la funcion LanzarProyeccion y sus parametros [sala, numero de proyección y asistentes_sentados]
						LanzarProyeccion(i,numProyecciones,asistentes_sentados);

						// Al terminar el pase o proyección volvemos a restablecer el aforo inicial de la sala, 
						// en exclusión mutua con el semáforo sMutex
						sWait(sMutex);
							shmAforos[i] = aforoMaximo;
							asientos_libres = aforoMaximo;
						sSignal(sMutex);

						// Ponemos a falso la variable lanzarProyeccion
						lanzarProyeccion=false;
					}

					// Tanto si se ha realizado la proyección como si no, leemos del Pipe el nuevo número de asistentes que entran
					asistentes_nuevos =  LeerPipe(arraySalas[i].pipe[CANAL_LECTURA]);

				}

				// LLegó el token ULTIMO_PASE y podemos tener asistentes_sentados.
				asistentes_sentados = aforoMaximo-asientos_libres; 

				// Estamos en el último pase, nos da igual el número de asistentes que haya sentados.
				// Si hay asistentes sentados lanzamos la última proyección, si no, no.
				if (asistentes_sentados > 0){
					// Incrementamos el contador de proyecciones
					numProyecciones++;

					// Incrementamos el contador de asistentes totales con la cantidad de asistentes_sentados.
					asistentes_totales += asistentes_sentados;

					// Se lanza la última proyección, con la funcion LanzarProyeccion y sus parametros, [sala, numero de proyección y asistentes_sentados]
					LanzarProyeccion(i,numProyecciones,asistentes_sentados);
				}

				// Al terminar la proyección volvemos a restablecer el aforo inicial de la sala, por su puesto en exclusión mutua
				// con el semaforo sMutex
				sWait(sMutex);
					shmAforos[i] = aforoMaximo;
				sSignal(sMutex);

				// El hijo (sala) ya termina, ya no va a haber más proyecciones.
				// Añade sus datos al fichero de registro.dat con la funcion CrearResumenProyecciones 
				CrearResumenProyecciones(i,numProyecciones,asistentes_totales);

				// Cerramos el canal de lectura del pipe
				close(arraySalas[i].pipe[CANAL_LECTURA]);

				//La sala se desvincula del buffer
				shmdt(shmAforos);

				// La sala termina diciendole a la taquilla (padre) el número de proyecciones que ha realizado en su variable de exit.
				printf("** Sala [%d] termina con [%d] proyecciones y un total de [%d] asistentes\n",i,numProyecciones, asistentes_totales); fflush(stdout);
				exit(numProyecciones);
			}
		} 
		// FIN BUCLE CREACION DE LOS HIJOS (SALAS)-------------------------------------------------------
		// ----------------------------------------------------------------------------------------------------
	//END TODO 4 ******************************************************************

	// Aqui solo llega el padre, las salas (hijos) hacen exit

	//BEGIN TODO 5 ******************************************************************
		// Esperamos a que TODAS las salas estén creadas y abiertas para recibir asistentes. 
		// Bucle de espera a recibir todas las señales. El manejador actualiza la variable salasAbiertas
		while(salasAbiertas != numSalas){
			pause();
		}

		printf("\nEmpezamos con los siguientes aforos\n");
		// En exclusión mutua accedemos al array compartido de aforos que los hijos han actualizado y lo mostramos.
		sWait(sMutex);
			printf("----------------------------------------------\n  ");
			for (int s=0; s<numSalas; s++){
				printf("[%d]",shmAforos[s]);
			}
			printf("\n----------------------------------------------\n");						
		sSignal(sMutex);

		// Cuando el padre llega aquí todas las salas de cine han abierto al público.

		// entradas_disponibles inicialmente se carga con el total de asistentes que entran al centro comercial. (Parámetro de main)
		int entradas_disponibles = totalAsistentes;
		int salaCine = 0;
		int entradas_pedidas = 0;
		int entradas_compradas = 0;
		int aforo_disponible_sala = 0;

		// Inicializamos el generador de numeros aleatorios
		srand(getpid());

		//En bucle, nos van comprando entradas mientras queden entradas disponibles en el centro comercial a día de hoy
		while(entradas_disponibles > 0){

			// Viene una persona o un grupo de personas y quieren comprar entradas.
			// Primero eligen la película o sala. Eleccion de salaCine (valor aleatorio entre 0 y numSalas-1). 
			// Ver funcion en func.h para generar aleatorios.
			// En salaCine ponemos un numero aleatorio para la sala pedida, desde 0 al numero de salas menos uno.
			salaCine = RandInt(1, numSalas) - 1;

			// La persona o grupo de personas solicitan las entradas a en la taquilla del cine.
			// Si resulta que el aforo disponible es menor que el que piden, se les dará sólo las entradas disponibles.
			// Si queda aforo para poder comprar las entradas pedidas se les da las que piden.

			// Aquí simulamos la petición de entradas en la taquilla.
			// entradas_pedidas un numero aleatorio entre 1 y 6
			entradas_pedidas = RandInt(1, 6);

			// La taquilla comprueba cuantas entradas (cuanto aforo) quedan dispoinbles en la sala pedida.
			// Para ello accede en exclusión mutua al array shmAforos
			
			// Se solicita acceso a la sección crítica con el semaforo sMutex
			sWait(sMutex);

				//Obtenemos el aforo de la sala pedida.
				aforo_disponible_sala = shmAforos[salaCine];

				//Si las entradas pedidas son más que el aforo disponible en la sala pedida les vendemos solo las que quedan.
				if (entradas_pedidas > aforo_disponible_sala){
					// en entradas_compradas le ponemos las que quedan libres.
					entradas_compradas = aforo_disponible_sala;
				}
				else{
					// Como si que se le pueden vender las que piden, se le asignan las entradas pedidas
					entradas_compradas = entradas_pedidas;
				}

				// Es posible que no queden tantas entradas disponibles como las que se han comprado
				// pues el aforo disponible de la sala puede ser al final mayor que las que quedan, 
				// en ese caso se ajusta las entradas_compradas a las que quedan disponibles.
				if (entradas_compradas > entradas_disponibles){
					entradas_compradas = entradas_disponibles;
				}

				// Reducimos el aforo disponible en la sala de cine según las entradas compradas.
				// Actualizamos la memoria compartida de esa sala de cine quitándole las entradas comparadas.
				shmAforos[salaCine] = aforo_disponible_sala - entradas_compradas;

				// Reducimos las entradas disponibles restando las compradas
				entradas_disponibles = entradas_disponibles - entradas_compradas;
				
			//Se sale de la sección crítica
			sSignal(sMutex);

			// Ahora que se han comprado las entradas para esa sala de cine,
			// se le comunica a la sala, via su Pipe, que se han comprado tantas entradas,
			// pero sólo si se han podido comprar, porque puede pasar que cuando se pidieron
			// entradas, la sala estuviese en proyección y con su aforo a cero.
			// Sólo si las entradas comparadas son más que cero, entonces se envían por el Pipe
			if (entradas_compradas > 0){
				EscribirPipe(arraySalas[salaCine].pipe[CANAL_ESCRITURA], entradas_compradas);
			}
		}
	//END TODO 5 ******************************************************************

	//BEGIN TODO 6 ******************************************************************
		// Ya no quedan asistentes por entrar en el centro comercial, pero es posible que haya salas que no han llenado su aforo 
		// y por tanto no han relizado la proyección, hay que avisarles de que realicen el último pase con los asistentes
		// que hayan sentado en la sala, aun sin estar completa.
		// En un bucle for, recorremos todas las salas y les enviamos por su Pipe el token ULTIMO_PASE que vale -1
		// para que hagan la última proyección (ver func.h) con los asistentes que tengan en ese momento.
		// Dentro del bucle aprovechamos para cerrar el canal de escritura en los pipes de las salas
		for (int s = 0; s < numSalas; s++){
			// Ecribimos en el pipe de la sala de cine el token
			EscribirPipe(arraySalas[s].pipe[CANAL_ESCRITURA], ULTIMO_PASE);

			// Cerramos el canal de escritura 
			close(arraySalas[s].pipe[CANAL_ESCRITURA]);
		}

		// El padre (taquilla) espera a que terminen los hijos (salas) tras su último pase o proyección.
		// Codificar el bucle para esperar la terminación de las salas
		// usando la funcion wait o la función waitpid
		int pidE;
		for (int k = 0; k < numSalas; k++)
		{
			pidE = wait(&status); // Esperamos la terminación de cualquier hijo
		}
	//END TODO 6 ******************************************************************

	// El padre termina.
	return 0;
}
